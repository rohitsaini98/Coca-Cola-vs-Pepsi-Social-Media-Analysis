# -*- coding: utf-8 -*-
"""
Created on Sun Nov 22 03:55:03 2020

@author: ROHIT SAINI
"""

import urllib.request
url = "https://en.wikipedia.org/wiki/The_Coca-Cola_Company"
page = urllib.request.urlopen(url)
from bs4 import BeautifulSoup
soup = BeautifulSoup(page, "lxml")
print(soup.prettify())

all_tables=soup.find_all("table")
all_tables

right_table=soup.find('table', class_='wikitable float-left')
right_table

A=[]
B=[]
C=[]
D=[]
E=[]
for row in right_table.findAll('tr'):
    cells=row.findAll('td')
    if len(cells)==5:
        A.append(cells[0].find(text=True))
        B.append(cells[1].find(text=True))
        C.append(cells[2].find(text=True))
        D.append(cells[3].find(text=True))
        E.append(cells[4].find(text=True))
import pandas as pd
df=pd.DataFrame(A,columns=['Year'])
df['Revenue in mil. USD']=B
df['Net income in mil. USD']=C
df['Price per share in USD']=D
df['Employees']=E


coca_cola = pd.DataFrame( df )
coca_cola.to_csv("Cola-Cola Finance.csv")